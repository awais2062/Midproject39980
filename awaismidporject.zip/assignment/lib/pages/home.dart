import 'package:flutter/material.dart';
import '../Products/product.dart';
import 'details.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> with SingleTickerProviderStateMixin {
  final List<Product> cars = [
    Product(
      name: 'Tesla Model S',
      image: 'assets/tesla.png',
      price: 7500000,
      description: 'Electric, stylish, and powerful!',
    ),
    Product(
      name: 'BMW 3 Series',
      image: 'assets/bmw.png',
      price: 4000000,
      description: 'A perfect blend of luxury and performance.',
    ),
    Product(
      name: 'Audi A6',
      image: 'assets/audi.png',
      price: 4500000,
      description: 'Comfort, technology, and performance at its best.',
    ),
    Product(
      name: 'Mercedes-Benz C-Class',
      image: 'assets/mercedes.png',
      price: 5500000,
      description: 'Luxury redefined with advanced technology.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Car Showroom'),
        backgroundColor: Colors.blueAccent,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: ListView.builder(
            itemCount: cars.length,
            itemBuilder: (context, index) {
              Product car = cars[index];
              return AnimatedOpacity(
                opacity: 1.0,
                duration: Duration(seconds: (index + 1) * 1), // 1 second delay
                child: Card(
                  margin: const EdgeInsets.symmetric(vertical: 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Image.asset(car.image, width: 200, height: 150),
                      const SizedBox(height: 10),
                      Text(
                        car.name,
                        style: const TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        '\RS ${car.price}',
                        style:
                        const TextStyle(fontSize: 16, color: Colors.grey),
                      ),
                      const SizedBox(height: 10),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => Details(product: car),
                            ),
                          );
                        },
                        child: const Text('View Details'),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
